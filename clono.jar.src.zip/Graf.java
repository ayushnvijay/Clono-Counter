/*    */ import javax.swing.JFrame;
/*    */ 
/*    */ public class Graf
/*    */ {
/*    */   public static void main(String[] args)
/*    */   {
/*  7 */     JFrame frame = new GrafFrame();
/*  8 */     frame.setBackground(new java.awt.Color(255, 255, 255));
/*  9 */     frame.setDefaultCloseOperation(3);
/* 10 */     frame.setVisible(true);
/*    */   }
/*    */ }


/* Location:              /Users/ayushnvijay/Desktop/clono.jar!/Graf.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */